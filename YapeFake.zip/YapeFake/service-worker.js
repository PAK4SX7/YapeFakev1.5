self.addEventListener('install', e => {
  e.waitUntil(
    caches.open('app-cache').then(cache =>
      cache.addAll(['./'])
    )
  );
});